#include <stdio.h>
#include <omp.h>
#define N    40
#define NUM_THREADS    4

int main (int argc, char **argv) {

    int i, frac, inicio, fim;
    int nthreads, tid;
    int a[N], b[N], c[N];
    
    for (i = 0; i < N; i++)
        a[i] = b[i] = i * 1.0;

    frac = (int) N / NUM_THREADS;

    #pragma omp parallel num_threads(NUM_THREADS) shared(a, b, c, frac) private(i, tid,inicio, fim)
    {
        nthreads = omp_get_num_threads();
        tid = omp_get_thread_num();

        inicio = frac * tid;
        fim = (inicio + frac) - 1;
        printf("Thread %d, de %d threads, calcula do indice %d ao indice %d \n", tid, nthreads, inicio, fim); 
        for (i = inicio; i <= fim; i++) {
            c[i] = a[i] + b[i];            
        }
    }  

    return 0;

}
