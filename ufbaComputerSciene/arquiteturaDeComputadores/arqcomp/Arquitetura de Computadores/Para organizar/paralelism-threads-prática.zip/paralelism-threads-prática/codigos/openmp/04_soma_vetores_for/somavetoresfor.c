#include <stdio.h>
#include <omp.h>
#define CHUNKSIZE 4
#define N    40

int main (int argc, char **argv) {

    int i, chunk;
    int nthreads, tid;
    int a[N], b[N], c[N];
    
    for (i = 0; i < N; i++)
        a[i] = b[i] = i * 1.0;
    chunk = CHUNKSIZE;
    
    #pragma omp parallel num_threads(8) shared(a, b, c, chunk) private(i, tid)
    {
        #pragma omp for schedule(static, chunk)
        for (i = 0; i < N; i++) {
            tid = omp_get_thread_num();
            nthreads = omp_get_num_threads();
            c[i] = a[i] + b[i];
            printf("Thread %d, de %d threads, calcula a iteraçao i =%d\n", tid, nthreads, i); 
        }
    }  

    return 0;

}
