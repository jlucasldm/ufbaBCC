#include <stdio.h>
#include <omp.h>

int main (int argc, char **argv)  {

    int nthreads, tid;

    printf("Trabalharemos com 4 threads\n");
    
    omp_set_num_threads(4);          		/*Inicializa o numero de threads na regiao paralela*/
    
    nthreads = omp_get_num_threads();		/*Confirma o numero total de threads inicializado*/
    
    printf("Numero de threads em execuçao = %d\n", nthreads);

    #pragma omp parallel private(tid)       	/*Regiao paralela*/
                                            
    {
        tid = omp_get_thread_num();         	/* Identificador da thread*/ 
        printf("Ola! Desde a thread = %d\n", tid);
        if (tid == 0) {                     	/* Thread mestre*/
            nthreads = omp_get_num_threads();
            printf("Numero de threads = %d\n", nthreads);
        }
    }  

    printf("Trabalharemos agora com 3 threads \n");

    omp_set_num_threads(3);
    nthreads = omp_get_num_threads();
    printf("Numero de threads em execucao = %d\n", nthreads);
   
    #pragma omp parallel
    {
        tid = omp_get_thread_num();
        printf("Ola desde a thread = %d\n", tid);
        if (tid == 0) {
            nthreads = omp_get_num_threads();
            printf("Numero de threads = %d\n", nthreads);
        }
    }

    return 0;

}


