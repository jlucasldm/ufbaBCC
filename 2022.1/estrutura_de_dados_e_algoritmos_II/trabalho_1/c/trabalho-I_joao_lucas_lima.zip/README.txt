DISCENTE: JOÃO LUCAS LIMA DE MELO


A resolução do trabalho consiste no arquivo main.c, que importa dos demais 
arquivos .h funções, structs e variáveis globais.

Foi utilizado o compilador gcc para compilação de main.c. 

O arquivo binário "dado", uma vez criado pelo programa, será salvo 
no diretório atual.