//
// Created by Luca on 03/06/2022.
//

#ifndef CONSULTASIMPLES_H
#define CONSULTASIMPLES_H

#include "registros.h"

bool consultaSimplesUtil(char autor[21], bool exists, int index, int profundidade, int offset, char filename[21]);

bool consultaSimples(char autor[21]);

#endif //CONSULTASIMPLES_H
