#ifndef CONSTROIARVORE_H
#define CONSTROIARVORE_H

void constroiArvore();

#endif //CONSTROIARVORE_H
