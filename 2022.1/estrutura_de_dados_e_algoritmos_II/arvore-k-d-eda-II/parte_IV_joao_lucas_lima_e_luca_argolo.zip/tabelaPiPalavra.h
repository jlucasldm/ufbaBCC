#ifndef TABELAPIPALAVRA_H
#define TABELAPIPALAVRA_H

void tabelaPiPalavra(char palavra[31]);

#endif //TABELAPIPALAVRA_H
