#ifndef IMPRIMEARVORE_H
#define IMPRIMEARVORE_H

void imprimeIndiceArvoreUtil(int index, int profundidade, int offset);

void imprimeIndiceArvore();

#endif //IMPRIMEARVORE_H
