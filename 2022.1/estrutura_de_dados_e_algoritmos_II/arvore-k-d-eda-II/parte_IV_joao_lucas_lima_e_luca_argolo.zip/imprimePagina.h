#ifndef IMPRIMEPAGINA_H
#define IMPRIMEPAGINA_H

#include "registros.h"

int imprimePaginaUtil(int indice, int indice_original, bool exists, int index, int profundidade, int offset, char* filename);

void imprimePagina(int indice);

#endif //IMPRIMEPAGINA_H
