//
// Created by kid-a on 04/06/2022.
//

#ifndef INICIALIZAPAGINAS_H
#define INICIALIZAPAGINAS_H

void inicializaPaginas();

#endif //INICIALIZAPAGINAS_H
