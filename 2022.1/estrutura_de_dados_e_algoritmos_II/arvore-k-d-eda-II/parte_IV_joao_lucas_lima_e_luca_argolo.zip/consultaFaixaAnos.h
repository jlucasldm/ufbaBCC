//
// Created by Luca on 03/06/2022.
//

#ifndef CONSULTAFAIXAANOS_H
#define CONSULTAFAIXAANOS_H

#include "registros.h"

bool consultaFaixaAnosUtil(int n1, int n2, bool exists, int index, int profundidade, int offset, char filename[21]);

bool consultaFaixaAnos(int n1, int n2);

#endif //CONSULTAFAIXAANOS_H
