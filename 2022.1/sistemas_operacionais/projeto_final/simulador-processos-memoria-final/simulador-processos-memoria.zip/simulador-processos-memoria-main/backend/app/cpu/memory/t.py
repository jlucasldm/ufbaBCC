from collections import Counter

d = Counter()

d[0]+=1
d[0]+=1
d[1]+=1
d[1]+=1
d[1]+=1

print()


