%fatos
aluno(joao, calculo).
aluno(maria, calculo).
aluno(joel, programacao).
aluno(joel, estrutura).

frequenta(joao, ufba).
frequenta(maria, ufba).
frequenta(joel, ifba).

professor(carlos, calculo).
professor(ana_paula, estrutura).
professor(pedro, programacao).

funcionario(pedro, ifba).
funcionario(ana_paula, ufba).
funcionario(carlos, ufba).
funcionario(antonio, ufba).

